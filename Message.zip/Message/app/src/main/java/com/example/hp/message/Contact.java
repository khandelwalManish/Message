package com.example.hp.message;


public class Contact
{
   private String name, email ,phone  ,uName, pass;

    public void setName(String name)
{
    this.name = name;
}

    public String getName()
    {
        return this.name;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return this.email;
    }
    public void setPhone(String phone)
    {
        this.phone = phone;
    }

    public String getPhone()
    {
        return this.phone;
    }
    public void setUName(String uName)
    {
        this.uName = uName;
    }

    public String getUName()
    {
        return this.uName;
    }
    public void setPass(String pass)
    {
        this.pass = pass;
    }

    public String getPass()
    {
        return this.pass;
    }
}
